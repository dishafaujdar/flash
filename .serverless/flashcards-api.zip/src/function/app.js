import express from 'express';
import mysql from 'mysql2/promise';
import cors from 'cors';
import serverless from 'serverless-http';
import dotenv from 'dotenv';
dotenv.config();
const app = express();

app.use(express.json());
app.use(cors());

const pool = mysql.createPool({
  host: process.env.DB_HOST,
  port: process.env.DB_PORT,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  waitForConnections: true,
  connectionLimit: 10000,
  queueLimit: 0,
});

const getConnection = async (req, res, next) => {
  try {
    req.db = await pool.getConnection();
    console.log('Database connection established');
    next();
  } catch (err) {
    res.status(500).json({ error: 'Database connection error', details: err.message });
  }
};

app.use(getConnection);

app.get('/flashcards', async (req, res) => {
  try {
    const query = 'SELECT * FROM flashcards'; 
    const [results] = await req.db.query(query);  
    req.db.release();
    res.json({
      statusCode: 200,
      body: JSON.stringify(results),
      headers: { 'Content-Type': 'application/json' }
    });
  } catch (err) {
    req.db.release();
    res.status(500).json({ error: err.message });
  }
});

app.post('/flashcards', async (req, res) => {
  const { question, answer } = req.body;
  const query = 'INSERT INTO flashcards (question, answer) VALUES (?, ?)';
  try {
    const [result] = await req.db.query(query, [question, answer]);
    req.db.release();
    res.json({
      statusCode: 200,
      body: JSON.stringify({ id: result.insertId, question, answer }),
      headers: { 'Content-Type': 'application/json' }
    });
  } catch (err) {
    req.db.release();
    res.status(500).json({ error: err.message });
  }
});

app.put('/flashcards/:id', async (req, res) => {
  const { id } = req.params;
  const { question, answer } = req.body;
  const query = 'UPDATE flashcards SET question = ?, answer = ? WHERE id = ?';
  try {
    await req.db.query(query, [question, answer, id]);
    req.db.release();
    res.json({
      statusCode: 200,
      body: JSON.stringify({ id, question, answer }),
      headers: { 'Content-Type': 'application/json' }
    });
  } catch (err) {
    req.db.release();
    res.status(500).json({ error: err.message });
  }
});

app.delete('/flashcards/:id', async (req, res) => {
  const { id } = req.params;
  const query = 'DELETE FROM flashcards WHERE id = ?';
  try {
    await req.db.query(query, [id]);
    req.db.release();
    res.json({
      statusCode: 200,
      body: JSON.stringify({ id }),
      headers: { 'Content-Type': 'application/json' }
    });
  } catch (err) {
    req.db.release();
    res.status(500).json({ error: err.message });
  }
});

module.exports.handler = serverless(app);



